<?php
//000000000000
 exit();?>
a:15:{s:14:"admin_username";s:7:"landxin";s:14:"admin_password";s:32:"45bdbc7a1b60d42c63031a5992af7557";s:5:"title";s:11:"By 随心Ln";s:8:"keywords";s:26:"随心Ln自用文件共享";s:11:"description";s:52:"随心Ln自用文件共享-文件管理-文件系统";s:8:"announce";s:250:"本盘为（随心Ln）自用文件管理系统，本页面内所见文件均为（大部分来源于网络）公开项目，其内或有欺诈广告存在，需有防骗意识！被骗与本站无关，后果自负。
文件资源陆续添加中...";s:6:"footer";s:118:"<br>
随机一言：

<script type="text/javascript" src="https://api.xygeng.cn/one/get/">
<br>
</script>
<br>
";s:11:"name_encode";s:4:"utf8";s:9:"file_hash";s:1:"0";s:13:"cache_indexes";s:1:"0";s:9:"readme_md";s:1:"1";s:4:"auth";s:1:"0";s:3:"nav";s:0:"";s:13:"admin_session";s:32:"916a73e6bf022164e28d9ce7a51e1ece";s:15:"admin_lastlogin";s:19:"2023-02-13 18:25:09";}