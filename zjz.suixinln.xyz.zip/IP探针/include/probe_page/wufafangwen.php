<html><head>
<meta http-equiv="Content-Type" content="textml;charset=UTF-8">
   <style>body{background-color:#FFFFFF}</style> 
<title>TestPage184</title>
  <script language="javascript" type="text/javascript">
         window.onload = function () { 
           document.getElementById("mainFrame").src= "http://batit.aliyun.com/alww.html"; 
            }
</script>   
</head>
  <body>
    <iframe style="width:860px; height:500px;position:absolute;margin-left:-430px;margin-top:-250px;top:50%;left:50%;" id="mainFrame" src="http://batit.aliyun.com/alww.html" frameborder="0" scrolling="no"></iframe>
    
      

</body></html>