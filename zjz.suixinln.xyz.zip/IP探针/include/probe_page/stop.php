<?php
/*
stop
*/
echo '<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>抱歉，站点已暂停</title>
<style>
html,body,div,h1,*{margin:0;padding:0;}
body{
	background-color:#fefefe;
	color:#333
}
.box{
	width:580px;
	margin:0 auto;
}
h1{
	font-size:20px;
	text-align:center; 
	background:url(https://www.bt.cn/stop.png) no-repeat top center; 
	padding-top:160px;
	margin-top:30%;
	font-weight:normal;
}

</style>
</head>

<body>
<div class="box">
<h1>抱歉！该站点已经被管理员停止运行，请联系管理员了解详情！</h1>
</div>
</body>
</html>
';
?>