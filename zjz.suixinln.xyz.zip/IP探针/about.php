<?php include_once("./include/reception/header.php"); ?>
<fieldset class="layui-elem-field">
  <legend>关于我们</legend>
  <div class="layui-field-box">
    <h1>国内领先的网络安全学习平台</h1>
	<br>
	<h1>有问题联系下方</h1>
	<br>
	<br>
	<br>
	<h1>TG:Ron820</h1>
	<br>
	<h1></h1>
  </div>
</fieldset>
<?php include_once("./include/reception/footer.php"); ?>
